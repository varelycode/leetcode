import UIKit

// naive solution
func twoSum(_ nums: [Int], _ target: Int) -> [Int] {
    
    var result: [Int] = []
    for i in nums  {
        for j in nums{
            if (i == j){
                continue
            }
            
            
            
            if (j == target - i){
                result.append(nums.firstIndex(of: i) ?? 0)
                result.append(nums.firstIndex(of: j) ?? 0)
                
            }
            
        }
        // if we found a single solution, end this
        if (result.count == 2){
            break
        }
    }

return result
    
}

//print(twoSum([2, 7, 11, 15], 9));


//use sets as an alternative (not from scratch lolol)

func twoSumHash(_ nums: [Int], _ target: Int) -> [Int] {
    
    let keys = insert(nums)
    var result: [Int] = []
    
    
    for i in nums{
        let sum  = target - i
        if search(nums, keys, sum) == true {
            result.append(nums.firstIndex(of: i) ?? 0)
            result.append(nums.firstIndex(of: sum) ?? 0)
            break
        }else{
            continue
        }
    }

    print("twoSumHashResult")
    print(result)
    return result
}


func insert(_ nums: [Int]) -> [Int]{
    
    let tableSize = nums.count
    var array: [Int] = []
    var keys: [Int] = []
    
    for i in nums{
        //print(i.hashValue)
        let hashValue =  i % (tableSize + 3)
        keys.append(hashValue)
    }
    
    
//    print(array)
//    print(keys)
    return keys
    
}

func search(_ nums: [Int],_ keys: [Int], _ sum:Int) -> Bool{
    
    let tableSize = nums.count
    let sumValue =  sum % (tableSize + 3)
    print(keys)
    print(sumValue)
    
    if(keys.contains(sumValue)){
        print("true")
        return true
    }
    else{
        return false
    }
    
}


//print(twoSumHash([2, 7, 11, 15], 9));
print(twoSumHash([41,7,11,34,56,98,43,3,4,1,10,42], 46));
